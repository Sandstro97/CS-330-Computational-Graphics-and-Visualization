#pragma once
#ifndef __UTILS_H__
#define __UTILS_H__

unsigned int load_wrap_texture(const char* texture_path);

#endif//__UTILS_H__